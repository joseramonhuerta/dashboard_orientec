<?php
class ConfiguracionesModel extends Mysql{
    public function __construct(){
        parent::__construct();
    }

    public function selectConfiguracion(){
        $sql = "SELECT id_configuracion, beneficiario, numero_cuenta, leyenda_pago_oxxo, codigo_registro, comision FROM cat_configuraciones_app WHERE status = 'A' LIMIT 1";
        $request = $this->select($sql);
        return $request;    
    }

    public function updateConfiguracion(int $id_configuracion, string $beneficiario, string $numero_cuenta, string $leyenda_pago_oxxo, string $codigo_registro, float $comision){
        $return = 0;
        $sql = "UPDATE cat_configuraciones_app 
                SET beneficiario = ?, numero_cuenta = ?, leyenda_pago_oxxo = ?, codigo_registro = ?, comision = ?
				WHERE id_configuracion = $id_configuracion ";
        $arrData = array($beneficiario, $numero_cuenta, $leyenda_pago_oxxo, $codigo_registro, $comision);
        
        $request = $this->update($sql, $arrData); 
        
        return $request;
    }
}