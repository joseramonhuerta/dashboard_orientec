let divLoading = document.querySelector("#divLoading");

getConfiguracion();

function getConfiguracion(){
    let request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
    let ajaxUrl = base_url+'/Configuraciones/getConfiguracion';
    request.open("GET",ajaxUrl,true);
    request.send();
    request.onreadystatechange = function(){

        if(request.readyState == 4 && request.status == 200){
            let objData = JSON.parse(request.responseText);

            if(objData.success)
            {
                document.querySelector("#idConfiguracion").value = objData.data.id_configuracion;
                document.querySelector("#txtBeneficiario").value = objData.data.beneficiario;
                document.querySelector("#txtNumeroCuenta").value = objData.data.numero_cuenta;
                document.querySelector("#txtLeyendaPago").value = objData.data.leyenda_pago_oxxo;
                document.querySelector("#txtCodigoRegistro").value = objData.data.codigo_registro;              
                document.querySelector("#txtComision").value = objData.data.comision;              
                
            }
        }
    
        $('#modalFormDeposito').modal('show');
    }
}

document.addEventListener('DOMContentLoaded', function(){
    if(document.querySelector("#formConfiguracion")){
        let formConfiguracion = document.querySelector("#formConfiguracion");
        formConfiguracion.onsubmit = function(e){
            e.preventDefault();

            divLoading.style.display = "flex";
            let request = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
            let ajaxUrl = base_url+'/Configuraciones/setConfiguracion';
            let formData = new FormData(formConfiguracion);
            request.open("POST", ajaxUrl, true);
            request.send(formData);
            request.onreadystatechange = function(){
                if(request.readyState == 4 && request.status == 200){
                    let objData = JSON.parse(request.responseText);            
                    if(objData.success){
                      swal("Configuraciones", objData.msg,"success");     
                    }else{
                       swal("Error",objData.msg,"error");     
                    }
                }
                divLoading.style.display = "none";
                return false;
            }
            
            
        }
    }

});