<?php 
	
	const BASE_URL = "http://localhost/dashboard_orientec";
	
	date_default_timezone_set('America/Mazatlan');

	const DB_HOST = "localhost";
	const DB_NAME = "servfix_manualesapp";
	const DB_USER = "root";
	const DB_PASSWORD = "";
	const DB_CHARSET = "utf8";

	const SPD = ".";
	const SPM = ",";

	const SMONEY = "$";



 ?>