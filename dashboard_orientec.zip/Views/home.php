<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $data['page_tag']; ?></title>
</head>
<body>
	<h1>Pagina Index</h1>
	
</body>
</html>