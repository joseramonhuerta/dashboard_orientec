<?php
class Configuraciones extends Controllers{
    public function __construct(){
        session_start();
        if(empty($_SESSION['login'])){
            header('Location:'.base_url().'/login');
        }
        parent::__construct();
    }

    public function Configuraciones(){
        $data['page_tag'] = "Configuraciones";
        $data['page_title'] = "Configuraciones <small>Orientec</small>";
        $data['page_name'] = "configuraciones";
        $data['page_functions_js'] = "functions_configuraciones.js";
        $this->views->getView($this, "configuraciones", $data);
    }

    public function getConfiguracion(){
        $arrData = $this->model->selectConfiguracion();
        if(empty($arrData)){
            $arrResponse = array('success' => false, 'msg' => 'Datos no encontrados.');
        }else{
            $arrResponse = array('success' => true, 'data' => $arrData);
        }
        echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);

        die();
    }

    public function setConfiguracion(){
        if($_POST){
            if(empty($_POST['idConfiguracion'])){
               $arrResponse = array('success' => false, 'msg' => 'Datos incorrectos.');     
            }else{
               $idConfiguracion = intval($_POST['idConfiguracion']);
               $beneficiario = ucwords(strClean($_POST['txtBeneficiario'])); 
               $numero_cuenta = ucwords(strClean($_POST['txtNumeroCuenta']));
               $leyenda_pago = ucwords(strClean($_POST['txtLeyendaPago']));  
               $codigo_registro = ucwords(strClean($_POST['txtCodigoRegistro']));  
               $comision = doubleval($_POST['txtComision']);

               $request = $this->model->updateConfiguracion( $idConfiguracion, $beneficiario, $numero_cuenta, $leyenda_pago, $codigo_registro, $comision);
                
               if($request > 0){
                    $arrResponse = array('success' => true, 'msg' => 'Datos guardados correctamente.');
               }else{
                    $arrResponse = array('success' => false, 'msg' => 'No es posible almacenar los datos.');
               }
            }
            echo json_encode($arrResponse, JSON_UNESCAPED_UNICODE);
        }
        die();
    }

}
?>